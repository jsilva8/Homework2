import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) throws IOException{
        File myFile =new File("car_data.csv");

        while (inputFile.hasNext()) {
            Scanner inputFile = new Scanner(myFile);
            Car car = new Car();
            ArrayList<Car> CarList = new ArrayList<Car>();
            CarList.add(car);
        }
        PrintWriter outputFile = new PrintWriter("processed_cars.txt");
        outputFile.println(car);
        outputFile.close();
    }
}
class Car extends vehicle {
    private String make;
    private String model;

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }


    public void updateFuelRemaining () {
        hours timeTravelled;

    }
}
class vehicle {
    private double fuel;
    private double mpg;
    private int currentSpeed;
    private double baseMpg;
    private double scaleFactor;

    public void updateMpg() {
        mpg=baseMpg-(scaleFactor*currentSpeed) + (Math.pow(0.02718281828)*(currentSpeed)/20));
    }
}